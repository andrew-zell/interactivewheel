# Zoom Product Wheel — Quick Start

1) Replace **public/product-wheel.svg** with your real SVG. Keep the filename.
2) Install & run:
```bash
npm i
npm run dev
```
3) Edit copy in **src/data/content.ts** (titles, subtitles, points).
4) Adjust click areas in **src/data/hotspots.ts** (percent coords).
5) Fonts: Inter (body) & Montserrat (headers) via Google Fonts in `index.html`.
6) Animations: hover glow + scale, click pulse, 250ms transitions, ESC + × to close.
