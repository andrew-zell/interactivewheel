import { motion } from "framer-motion";
import { hotspots, type Hotspot, type ItemKey } from "../data/hotspots";

export default function Wheel({ onSelect }: { onSelect: (k: ItemKey)=>void }) {
  return (
    <div className="mx-auto max-w-6xl px-4 py-12 md:py-16">
      <div className="relative w-full">
        <img
          src="/product-wheel.svg"
          alt="Zoom Product Wheel"
          className="w-full h-auto rounded-xl shadow-2xl select-none"
          draggable={false}
        />
        {hotspots.map((hs) => (
          <HotspotButton key={hs.key} hs={hs} onSelect={onSelect} />
        ))}
      </div>
    </div>
  );
}

function HotspotButton({ hs, onSelect }: { hs: Hotspot; onSelect: (k: ItemKey)=>void }) {
  return (
    <motion.button
      aria-label={hs.label}
      className="group absolute outline-none"
      style={{
        left: `${hs.left}%`,
        top: `${hs.top}%`,
        width: `${hs.w}%`,
        height: `${hs.h}%`,
        transform: "translate(-50%, -50%)",
        borderRadius: 12
      }}
      whileHover={{ scale: 1.05 }}
      whileTap={{ scale: 0.97 }}
      onClick={() => onSelect(hs.key)}
    >
      <span className="sr-only">{hs.label}</span>
      <span className="absolute inset-0 rounded-xl ring-0 transition-all duration-200 group-hover:shadow-glow"></span>
    </motion.button>
  );
}
