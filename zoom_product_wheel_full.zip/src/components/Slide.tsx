import { motion } from "framer-motion";
import type { ItemData } from "../data/content";

export default function Slide({
  itemKey, data, index, onClose
}: {
  itemKey: string; data: ItemData; index: number; onClose: ()=>void;
}) {
  const detailsLeft = index % 2 === 0; // alternate per product
  return (
    <div className="absolute inset-0 flex items-center justify-center px-4">
      <motion.div
        initial={{ y: 18, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        exit={{ y: 18, opacity: 0 }}
        transition={{ duration: 0.25 }}
        className="relative w-full max-w-6xl rounded-2xl bg-black/40 backdrop-blur-xl border border-white/10 shadow-2xl"
      >
        {/* Close */}
        <button
          aria-label="Close"
          onClick={onClose}
          className="absolute right-4 top-4 h-10 w-10 rounded-lg bg-white/10 hover:bg-white/15 transition flex items-center justify-center"
        >
          <span className="text-xl leading-none">×</span>
        </button>

        {/* Content */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 md:gap-10 p-6 md:p-10">
          {/* Details */}
          <div className={detailsLeft ? "" : "md:order-2"}>
            <h1 className="font-display text-3xl md:text-4xl font-semibold tracking-tight mb-4">
              {data.title}
            </h1>
            <p className="text-slate-300 mb-4">{data.subtitle}</p>
            <ul className="space-y-3 text-slate-200">
              {data.points.map((p, i) => (
                <li key={i} className="leading-relaxed">
                  <span className="mr-2 align-middle">•</span>{p}
                </li>
              ))}
            </ul>
          </div>

          {/* Image placeholder */}
          <div className={detailsLeft ? "" : "md:order-1"} >
            <div className="flex items-center justify-center h-full">
              <div className="aspect-[4/3] w-full max-w-[900px] min-w-[800px] max-h-[700px] bg-white/5 rounded-xl border border-white/10 flex items-center justify-center">
                <span className="text-slate-400">Image Placeholder (≥800px)</span>
              </div>
            </div>
          </div>
        </div>
      </motion.div>
    </div>
  );
}
